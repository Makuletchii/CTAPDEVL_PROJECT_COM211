package com.villanueva.spoton;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.io.IOException;
import androidx.annotation.Nullable;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.provider.MediaStore;
import android.widget.TextView;
import com.villanueva.spoton.ml.Model;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class results extends AppCompatActivity {

    ImageView imageview; // ImageView to display the selected image
    Bitmap bitmap; // Bitmap to hold the image
    TextView resultText; // TextView to display the classification result
    int imageSize = 32; // Model's expected input size

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this); // Enable edge-to-edge layout
        setContentView(R.layout.activity_results); // Set the content view to activity_results layout
        resultText = findViewById(R.id.result); // Initialize resultText
        imageview = findViewById(R.id.imageview); // Initialize imageview
        bitmap = imageholder.getInstance().getBitmap(); // Get the bitmap from a singleton instance

        if (bitmap != null) {
            // Display the original high-quality image
            imageview.setImageBitmap(bitmap);
            // Prepare image for classification by resizing it
            Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, imageSize, imageSize, false);
            classifyImage(resizedBitmap); // Classify the image
        } else {
            // Show a toast message if there's no bitmap
            Toast.makeText(this, "NO BITMAP", Toast.LENGTH_SHORT).show();
        }

        // Adjust view padding to accommodate system windows
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // Handle the result from an activity
        if (resultCode == RESULT_OK){ // If the result is okay
            if (requestCode == 3){ // If the request code is for retrieving the result from the camera
                Bitmap image = (Bitmap) data.getExtras().get("data"); // Get the image from the intent
                int dimension = Math.min(image.getWidth(), image.getHeight());
                image = ThumbnailUtils.extractThumbnail(image, dimension, dimension); // Create a thumbnail
                imageview.setImageBitmap(image); // Set the image in the imageview
                image = Bitmap.createScaledBitmap(image, imageSize, imageSize, false); // Resize the image
                classifyImage(image); // Classify the image
            } else { // For selecting an image from the gallery
                Uri imageUrl = data.getData(); // Get the image URI
                Bitmap image = null;
                try {
                    image = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUrl); // Get the bitmap from the URI
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                imageview.setImageBitmap(image); // Set the image in the imageview
                image = Bitmap.createScaledBitmap(image, imageSize, imageSize, false); // Resize the image
                classifyImage(image); // Classify the image
            }
        }
        super.onActivityResult(requestCode, resultCode, data); // Call the superclass method
    }

    public void classifyImage(Bitmap image){
        try {
            Model model = Model.newInstance(getApplicationContext()); // Initialize the model

            // Creates inputs for reference.
            TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 32, 32, 3}, DataType.FLOAT32); // Create a TensorBuffer for input
            ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4 * imageSize * imageSize * 3); // Allocate a byte buffer
            byteBuffer.order(ByteOrder.nativeOrder()); // Set the byte order to native order

            int[] intValues = new int[imageSize * imageSize]; // Create an array to hold pixel values
            image.getPixels(intValues, 0, image.getWidth(), 0, 0, image.getWidth(), image.getHeight()); // Get the pixels from the image
            int pixel = 0;
            for (int i = 0; i < imageSize; i++) {
                for (int j = 0; j < imageSize; j++) {
                    int val = intValues[pixel++]; // Get the pixel value
                    byteBuffer.putFloat(((val >> 16) & 0xFF) * (1.f / 1)); // Extract and normalize the red channel
                    byteBuffer.putFloat(((val >> 8) & 0xFF) * (1.f / 1)); // Extract and normalize the green channel
                    byteBuffer.putFloat((val & 0xFF) * (1.f / 1)); // Extract and normalize the blue channel
                }
            }
            inputFeature0.loadBuffer(byteBuffer); // Load the byte buffer into the input feature

            // Runs model inference and gets result.
            Model.Outputs outputs = model.process(inputFeature0); // Run the model inference
            TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer(); // Get the output tensor buffer

            float[] confidences = outputFeature0.getFloatArray(); // Get the confidence scores
            // Find the class with the highest confidence
            int maxPos = 0;
            float maxConfidence = confidences[0];
            for (int i = 1; i < confidences.length; i++) {
                if (confidences[i] > maxConfidence) {
                    maxConfidence = confidences[i];
                    maxPos = i;
                }
            }

            String[] classes = {"Acne", "Eczema"}; // Array of class names
            resultText.setText(classes[maxPos]); // Set the result text to the class with the highest confidence

            // Releases model resources if no longer used
            model.close(); // Close the model to release resources
        } catch (IOException e) {
            // TODO Handle the exception
        }
    }
    
    //    FOR BUTTONS TO GO BACK TO DESIGNATED ACTIVITIES ON CLICK
    public void goTopredict(View v) {
        Intent j = new Intent(this, predict.class);
        j.putExtra("imageBitmap", bitmap);
        startActivity(j);
        finish();
    }

    public void goTolibrary(View view) {
        Intent i = new Intent(this, library.class);
        startActivity(i);
        finish();
    }

    public void goToHome(View v) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        finish();
    }

    @Override
    public void onBackPressed() {
        ActivityHelper.openNewActivity(results.this, predict.class);
    }
}
