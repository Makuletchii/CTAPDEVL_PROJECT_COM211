package com.villanueva.spoton;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class predict extends AppCompatActivity {

    ImageView imageview;
    Bitmap bitmap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_predict);

        imageview = findViewById(R.id.imageview);
        Bitmap bitmap = imageholder.getInstance().getBitmap();


        if (bitmap != null) {
            imageview.setImageBitmap(bitmap);
        }else {
            Toast.makeText(this, "NO BITMAP", Toast.LENGTH_SHORT).show();
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }


    //    FOR BUTTONS TO GO BACK TO DESIGNATED ACTIVITIES ON CLICK
    public void goToidentify(View v){
        Intent i = new Intent(this, identify.class);
        startActivity(i);
        finish();
    }


    public void goToresults(View v){
        Intent j = new Intent(this, results.class);
        j.putExtra("imageBitmap", bitmap);
        startActivity(j);
        finish();
    }



    public void goToHome(View v){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        finish();
    }

    public void onBackPressed() {
        ActivityHelper.openNewActivity(predict.this, identify.class);
    }


}