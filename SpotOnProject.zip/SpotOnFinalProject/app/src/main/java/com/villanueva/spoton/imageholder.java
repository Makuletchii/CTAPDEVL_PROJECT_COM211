package com.villanueva.spoton;

import android.graphics.Bitmap;

public class imageholder {

    private static imageholder instance;
    private Bitmap bitmap;


//    PRIVATE CONSTRUCTOR SO NO INSTANTIATION
    private imageholder() {}

    public static imageholder getInstance() {
        if (instance == null) {
            instance = new imageholder();
        }
        return instance;
    }

//    SETTER-GETTER
    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

}

