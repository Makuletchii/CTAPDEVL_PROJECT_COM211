package com.villanueva.spoton;

import android.app.Activity;
import android.content.Intent;

public class ActivityHelper {

//    SINGLETON CLASS TO OPEN A NEW ACTIVITY AND FINISH THE CURRENT ACTIVITY FOR ONBACKPRESSED

    public static void openNewActivity(Activity currentActivity, Class<?> targetActivity) {
        Intent intent = new Intent(currentActivity, targetActivity);
        currentActivity.startActivity(intent);
        currentActivity.finish();
    }
}
