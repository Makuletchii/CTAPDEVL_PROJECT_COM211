package com.villanueva.spoton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class library extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_library);

    }

    //    FOR BUTTONS TO GO BACK TO DESIGNATED ACTIVITIES ON CLICK
    public void goToAcne(View v){
        Intent i = new Intent(this, acne.class);
        startActivity(i);
        finish();
    }

    public void goToEczema(View v){
        Intent i = new Intent(this, eczema.class);
        startActivity(i);
        finish();
    }

    public void goToHome(View v){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        finish();
    }

public void onBackPressed() {
    ActivityHelper.openNewActivity(library.this, MainActivity.class);
}
}