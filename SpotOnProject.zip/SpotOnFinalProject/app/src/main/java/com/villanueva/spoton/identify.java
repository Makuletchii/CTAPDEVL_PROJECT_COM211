package com.villanueva.spoton;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.io.IOException;


public class identify extends AppCompatActivity {

    ImageView imageview;
    int imageSize = 240;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_identify);
        imageview = findViewById(R.id.imageview);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
//        CALL THE PERMISSION HERE SO IT CAN POP-OUT FROM THE START
        getPermission();

    }

    //    TO BE ABLE TO ACCESS THE CAMERA
    public void goToCapture(View view) {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(i, 12);
    }

    // TO BE ABLE TO ACCESS THE GALLERY
    public void goToGallery(View view){
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, 10);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (resultCode == RESULT_OK){ //for camera
            if (requestCode == 12){ // for the retrieve result
// Extract Image from Intent
                Bitmap image = (Bitmap) data.getExtras().get("data");
// Get Dimensions
                int dimension = Math.min(image.getWidth(), image.getHeight());
// Resize
                image = ThumbnailUtils.extractThumbnail(image, dimension, dimension);
                imageview.setImageBitmap(image);
                image = Bitmap.createScaledBitmap(image, imageSize, imageSize, false);
                goToPredict(image);
            } else {
                Uri imageUrl = data.getData();
                Bitmap image = null;
                try {
                    image = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUrl);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                imageview.setImageBitmap(image);
                image = Bitmap.createScaledBitmap(image, imageSize, imageSize, false);
                goToPredict(image);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    // TO BE ABLE TO BRING THE IMAGE TO OTHER ACTIVITIES
    public void goToPredict(Bitmap bitmap){
        imageholder.getInstance().setBitmap(bitmap);
        Intent i = new Intent(this, predict.class);
        i.putExtra("imageBitmap", bitmap);
        startActivity(i);
        finish();
    }
    // FOR CAMERA PERMISSION
    public void getPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(identify.this, new String[]{Manifest.permission.CAMERA}, 11);
            }
        }
    }

    //    FOR BUTTONS TO GO BACK TO DESIGNATED ACTIVITIES ON CLICK
    public void goToHome(View v){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        finish();
    }

    public void onBackPressed() {
        ActivityHelper.openNewActivity(identify.this, MainActivity.class);
    }
}